import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Droplets, Wrench, Activity, Sprout, Shield, ChevronRight, ClipboardList, ShoppingBag, FileWarning, TrendingUp, Layers, Waves, Sparkles, Wind, Heart } from "lucide-react";
import { loadProfile, FUNDAMENTAL_OBJECTIVES, ADDITIONAL_OBJECTIVES, getRoutineForProfile, getWeekPlan, type DayPlan } from "@/lib/hair-data";

const objectiveIcons: Record<string, React.ElementType> = {
  hydration: Droplets, repair: Wrench, scalp: Activity, protection: Shield,
  growth: Sprout, density: Layers, "curl-definition": Waves,
  volume: Layers, "frizz-control": Wind, "scalp-soothing": Heart,
};

const objectiveLabels: Record<string, string> = {
  hydration: "Hydration", repair: "Repair", scalp: "Scalp Balance",
  protection: "Protection", growth: "Growth & Hair Loss Control",
  density: "Density & Thickness", "curl-definition": "Curl Definition Advanced",
  volume: "Volume", "frizz-control": "Frizz Control", "scalp-soothing": "Scalp Soothing",
};

const weekDays = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

const Home = () => {
  const navigate = useNavigate();
  const profile = loadProfile();
  const weekProgress = 65;
  const [activeObjective, setActiveObjective] = useState<string>("hydration");

  const objectives = [
    ...FUNDAMENTAL_OBJECTIVES.map((o, i) => ({ ...o, label: o.name, primary: i === 0 })),
    ...(profile?.additionalObjective
      ? (() => {
          const found = ADDITIONAL_OBJECTIVES.find(a => a.id === profile.additionalObjective);
          return found ? [{ ...found, label: found.name, primary: false }] : [];
        })()
      : []),
  ];

  const routine = profile ? getRoutineForProfile(profile) : [];
  const weekPlanData = profile ? getWeekPlan(profile) : {};

  const filteredSteps = routine.filter((s) =>
    s.objectives.some((o) => o.toLowerCase().includes(activeObjective === "scalp" ? "scalp" : activeObjective))
  );

  const isDayRelevant = (plan: DayPlan) => {
    return plan.objectives.some(o => o.toLowerCase().includes(activeObjective === "scalp" ? "scalp" : activeObjective));
  };

  return (
    <div className="px-5 pt-14 pb-6">
      {/* Header */}
      <div className="mb-6 flex items-start justify-between">
        <div>
          <p className="text-sm text-muted-foreground mb-0.5">Good morning</p>
          <h1 className="text-2xl font-bold text-foreground">Your Protocol</h1>
        </div>
        <button
          onClick={() => navigate("/profile")}
          className="flex items-center gap-1.5 rounded-full gradient-primary-soft border border-primary/20 px-3 py-1.5 mt-1"
        >
          <TrendingUp className="h-3 w-3 text-accent" />
          <span className="text-xs font-semibold text-accent">78</span>
          <span className="text-[9px] text-accent/70">↑</span>
        </button>
      </div>

      {/* Objectives bar */}
      <div className="mb-6 -mx-5 px-5 overflow-x-auto scrollbar-hide">
        <div className="flex gap-2.5 w-max">
          {objectives.map((obj) => {
            const Icon = objectiveIcons[obj.id] || Sparkles;
            const isActive = activeObjective === obj.id;
            return (
              <button
                key={obj.id}
                onClick={() => setActiveObjective(obj.id)}
                className={`flex items-center gap-1.5 rounded-full px-3.5 py-2 text-xs font-medium transition-all ${
                  isActive
                    ? "gradient-primary text-primary-foreground shadow-lg shadow-primary/20 ring-1 ring-primary/40"
                    : "bg-secondary/60 text-muted-foreground"
                }`}
              >
                <Icon className="h-3.5 w-3.5" />
                {obj.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Objective Routine Panel */}
      <div className="mb-5 animate-fade-in">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            {(() => { const Icon = objectiveIcons[activeObjective] || Sparkles; return <Icon className="h-4 w-4 text-accent" />; })()}
            <h3 className="text-sm font-semibold text-foreground">{objectiveLabels[activeObjective]} Steps</h3>
          </div>
        </div>
        {filteredSteps.length > 0 ? (
          <div className="space-y-2.5">
            {filteredSteps.map((s) => (
              <div key={s.step} className="flex items-center gap-3 rounded-xl bg-card p-3.5 border border-primary/15 glow-card">
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg gradient-primary text-sm font-bold text-primary-foreground">
                  {s.step}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground">{s.action}</p>
                  <p className="text-xs text-accent truncate">{s.product}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">{s.why}</p>
                </div>
                <span className="shrink-0 text-[10px] text-muted-foreground">{s.duration}</span>
              </div>
            ))}
          </div>
        ) : (
          <div className="rounded-xl bg-card p-4 border border-border/50 text-center">
            <p className="text-xs text-muted-foreground">This objective is addressed through your product formulations.</p>
          </div>
        )}
      </div>

      {/* Weekly Protocol */}
      <div className="mb-5">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold text-foreground">Weekly Protocol</h3>
          <button onClick={() => navigate("/routine")} className="flex items-center gap-1 text-xs text-accent font-medium">
            View Full Week <ChevronRight className="h-3 w-3" />
          </button>
        </div>
        <div className="-mx-5 px-5 overflow-x-auto scrollbar-hide">
          <div className="flex gap-2.5 w-max pb-1">
            {weekDays.map((day) => {
              const plan = (weekPlanData as Record<string, DayPlan>)[day];
              if (!plan) return null;
              const isToday = day === "Wed";
              const relevant = isDayRelevant(plan);
              const isWash = plan.type === "wash";

              return (
                <div
                  key={day}
                  className={`w-[120px] shrink-0 rounded-xl border p-3 transition-all ${
                    isToday ? "border-primary/40 glow-card" : relevant ? "border-primary/20 bg-card" : "border-border/30 bg-card/50"
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <p className={`text-xs font-bold ${isToday ? "text-accent" : "text-foreground"}`}>{day}</p>
                    {isToday && <span className="text-[8px] font-medium text-accent bg-primary/20 px-1.5 py-0.5 rounded-full">Today</span>}
                  </div>
                  {isWash && (
                    <div className="mb-1.5">
                      <span className="text-[9px] font-medium text-primary-foreground gradient-primary px-1.5 py-0.5 rounded-full">Wash</span>
                    </div>
                  )}
                  {plan.type === "rest" ? (
                    <p className="text-[10px] text-muted-foreground/50">Rest</p>
                  ) : relevant ? (
                    <div className="space-y-1">
                      {plan.actions.map(a => (
                        <p key={a} className="text-[10px] text-muted-foreground">{a}</p>
                      ))}
                    </div>
                  ) : (
                    <p className="text-[10px] text-muted-foreground/50">{plan.label}</p>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Weekly Progress */}
      <div className="mb-5 rounded-2xl bg-card p-4 border border-border/50">
        <div className="mb-2 flex items-center justify-between">
          <p className="text-sm font-semibold text-foreground">Weekly Progress</p>
          <span className="text-xs text-accent font-medium">{weekProgress}%</span>
        </div>
        <div className="h-2 w-full rounded-full bg-secondary">
          <div className="h-full rounded-full gradient-primary transition-all" style={{ width: `${weekProgress}%` }} />
        </div>
        <p className="mt-2 text-[11px] text-muted-foreground">4 of 6 daily routines completed</p>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-3 gap-2.5">
        {[
          { icon: ClipboardList, label: "Full Routine", path: "/routine" },
          { icon: ShoppingBag, label: "Products", path: "/products" },
          { icon: FileWarning, label: "Log Symptoms", path: "/profile" },
        ].map((action) => (
          <Button
            key={action.label}
            variant="soft"
            className="flex h-auto flex-col gap-1.5 rounded-xl py-4 text-xs"
            onClick={() => navigate(action.path)}
          >
            <action.icon className="h-5 w-5" />
            {action.label}
          </Button>
        ))}
      </div>
    </div>
  );
};

export default Home;
