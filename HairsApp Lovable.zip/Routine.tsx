import { useState } from "react";
import { Droplets, Wrench, Shield, ChevronRight, ChevronDown, Activity, Sprout, Layers, Waves, Check } from "lucide-react";
import { loadProfile, getRoutineForProfile, getWeekPlan, HAIR_TYPES, type DayPlan, type RoutineStep } from "@/lib/hair-data";

type ViewMode = "today" | "week";

const fullDayNames: Record<string, string> = {
  Mon: "Monday", Tue: "Tuesday", Wed: "Wednesday", Thu: "Thursday",
  Fri: "Friday", Sat: "Saturday", Sun: "Sunday",
};

const weekDays = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

const stepIcons: Record<string, React.ElementType> = {
  Cleanse: Droplets, Treat: Wrench, Condition: Droplets, Protect: Shield,
  "Define & Protect": Waves, "Scalp Treatment": Activity, "Oil Seal": Droplets,
};

const Routine = () => {
  const [view, setView] = useState<ViewMode>("today");
  const [expandedDay, setExpandedDay] = useState<string | null>(null);
  const profile = loadProfile();
  const routine = profile ? getRoutineForProfile(profile) : [];
  const weekPlanData = profile ? getWeekPlan(profile) : {};
  const typeData = profile ? HAIR_TYPES.find(t => t.type === profile.hairType) : null;

  const toggleDay = (day: string) => {
    setExpandedDay(expandedDay === day ? null : day);
  };

  // Get routine steps relevant to a day type
  const getStepsForDay = (plan: DayPlan) => {
    if (plan.type === "rest") return [];
    return routine.filter(s => plan.actions.some(a => s.action.toLowerCase().includes(a.toLowerCase())));
  };

  return (
    <div className="px-5 pt-14 pb-6">
      <h1 className="mb-1 text-2xl font-bold text-foreground">Your Routine</h1>
      <p className="mb-5 text-sm text-muted-foreground">
        {profile ? `Type ${profile.hairType}${profile.hairSubtype} · ${typeData?.label || ""}` : "Week 3 · Hydration Focus"}
      </p>

      {/* View Toggle – only Today & This Week */}
      <div className="mb-6 flex gap-1 rounded-xl bg-secondary/50 p-1">
        {(["today", "week"] as ViewMode[]).map((v) => (
          <button
            key={v}
            onClick={() => setView(v)}
            className={`flex-1 rounded-lg py-2.5 text-xs font-medium transition-all ${
              view === v ? "gradient-primary text-primary-foreground shadow-md" : "text-muted-foreground"
            }`}
          >
            {v === "today" ? "Today" : "This Week"}
          </button>
        ))}
      </div>

      {/* TODAY VIEW */}
      {view === "today" && (
        <div className="space-y-4 animate-fade-in">
          <div className="flex items-center gap-2 mb-2">
            <div className="h-2 w-2 rounded-full gradient-primary animate-pulse-glow" />
            <p className="text-xs text-accent font-medium">Wednesday · Treatment Day</p>
          </div>
          {routine.map((item) => {
            const Icon = stepIcons[item.action] || Shield;
            return (
              <div key={item.step} className="rounded-2xl bg-card border border-border/50 overflow-hidden">
                <div className="p-4">
                  <div className="flex items-start gap-3">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl gradient-primary text-primary-foreground font-bold text-sm">
                      {item.step}
                    </div>
                    <div className="flex-1">
                      <p className="text-base font-semibold text-foreground mb-0.5">{item.action}</p>
                      <p className="text-sm text-accent mb-2">{item.product}</p>
                      <p className="text-xs text-muted-foreground leading-relaxed mb-2">{item.why}</p>
                      <p className="text-xs text-muted-foreground">⏱ {item.duration}</p>
                      <div className="mt-2.5 flex flex-wrap gap-1.5">
                        {item.objectives.map((o) => (
                          <span key={o} className="rounded-full bg-primary/10 px-2.5 py-0.5 text-[10px] font-medium text-accent">{o}</span>
                        ))}
                      </div>
                      {profile && (
                        <p className="mt-2 text-[10px] text-accent/60">Selected for Type {profile.hairType}{profile.hairSubtype}</p>
                      )}
                    </div>
                  </div>
                </div>
                <button className="flex w-full items-center justify-center gap-1 border-t border-border/50 py-2.5 text-xs text-muted-foreground hover:text-accent transition-colors">
                  View alternative <ChevronRight className="h-3 w-3" />
                </button>
              </div>
            );
          })}
        </div>
      )}

      {/* WEEK VIEW – 7 Day Cards */}
      {view === "week" && (
        <div className="space-y-3 animate-fade-in">
          {weekDays.map((day) => {
            const plan = (weekPlanData as Record<string, DayPlan>)[day];
            if (!plan) return null;
            const isToday = day === "Wed";
            const isExpanded = expandedDay === day;
            const isWash = plan.type === "wash";
            const isRest = plan.type === "rest";
            const daySteps = getStepsForDay(plan);

            return (
              <div
                key={day}
                className={`rounded-2xl bg-card border overflow-hidden transition-all ${
                  isWash ? "border-primary/40 glow-card" : "border-border/50"
                } ${isToday ? "ring-1 ring-primary/30" : ""}`}
              >
                {/* Day header – tappable */}
                <button
                  onClick={() => toggleDay(day)}
                  className="flex w-full items-center gap-3 p-4 text-left"
                >
                  <div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-xs font-bold ${
                    isWash ? "gradient-primary text-primary-foreground" : isRest ? "bg-secondary text-muted-foreground" : "bg-accent/15 text-accent"
                  }`}>
                    {day}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-semibold text-foreground">{fullDayNames[day]}</p>
                      {isToday && (
                        <span className="text-[10px] font-medium text-accent bg-primary/20 px-2 py-0.5 rounded-full">Today</span>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5">{plan.label}</p>
                  </div>
                  <ChevronDown className={`h-4 w-4 text-muted-foreground transition-transform ${isExpanded ? "rotate-180" : ""}`} />
                </button>

                {/* Objective chips */}
                <div className="px-4 pb-3 flex flex-wrap gap-1.5">
                  {plan.objectives.map((obj) => (
                    <span key={obj} className="rounded-full bg-primary/10 px-2.5 py-0.5 text-[10px] font-medium text-accent">
                      {obj}
                    </span>
                  ))}
                </div>

                {/* Actions checklist (always visible compact) */}
                {!isRest && !isExpanded && (
                  <div className="px-4 pb-3 flex flex-wrap gap-2">
                    {plan.actions.map((action) => (
                      <div key={action} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                        <div className="h-3.5 w-3.5 rounded border border-border/60 flex items-center justify-center">
                          <Check className="h-2.5 w-2.5 opacity-0" />
                        </div>
                        {action}
                      </div>
                    ))}
                  </div>
                )}

                {isRest && !isExpanded && (
                  <div className="px-4 pb-3">
                    <p className="text-xs text-muted-foreground/60">No active steps — let your hair rest & recover.</p>
                  </div>
                )}

                {/* Expanded: full detailed steps */}
                {isExpanded && (
                  <div className="border-t border-border/50 p-4 space-y-3 animate-fade-in">
                    {isRest ? (
                      <div className="text-center py-2">
                        <p className="text-sm text-muted-foreground">Rest Day</p>
                        <p className="text-xs text-muted-foreground/60 mt-1">No active routine. Focus on protecting your hair while it recovers.</p>
                      </div>
                    ) : daySteps.length > 0 ? (
                      daySteps.map((step) => {
                        const Icon = stepIcons[step.action] || Shield;
                        return (
                          <div key={step.step} className="flex items-start gap-3">
                            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg gradient-primary text-sm font-bold text-primary-foreground">
                              {step.step}
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium text-foreground">{step.action}</p>
                              <p className="text-xs text-accent">{step.product}</p>
                              <p className="text-[10px] text-muted-foreground mt-0.5">{step.why}</p>
                              <p className="text-[10px] text-muted-foreground mt-0.5">⏱ {step.duration}</p>
                            </div>
                          </div>
                        );
                      })
                    ) : (
                      <div className="text-center py-2">
                        <p className="text-xs text-muted-foreground">Routine steps for this day are covered by your daily products.</p>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default Routine;
